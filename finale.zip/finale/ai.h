#ifndef AI_H_
#define AI_H_
#include"fonctions.h"

Enemy gestion_ai(Hero hero,Enemy enemy);
void affichageattack(Enemy *enemy,SDL_Surface *screen);



#endif
