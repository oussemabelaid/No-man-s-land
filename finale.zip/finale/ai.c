#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <math.h>
#include <time.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <string.h>
#include "ai.h"
#include"fonctions.h"




Enemy gestion_ai(Hero hero,Enemy enemy)

 {
int d;

d=enemy.x5-hero.x;
	if(enemy.x5>=4000 && enemy.x5<=5300)
	{


if(d<=250 && d>=0)
{
enemy.x5-=7;
if( enemy.numeroimage>=18 && enemy.numeroimage<22)
enemy.numeroimage++;
else
enemy.numeroimage=18;
}

else if(enemy.x5>4400 && enemy.direction2==0)
{
enemy.x5-=3;
if( enemy.numeroimage>=6 && enemy.numeroimage<11)
enemy.numeroimage++;
else 
enemy.numeroimage=6;
}



else if(d<0 && d>=-250)
{enemy.x5+=7;
if(enemy.numeroimage>=12 && enemy.numeroimage<16)
enemy.numeroimage++;
else 
enemy.numeroimage=12;
}

else if(enemy.x5<4600 && enemy.direction2==1)
{enemy.x5+=3;
if(enemy.numeroimage<5)
enemy.numeroimage++;
else 
enemy.numeroimage=0;
}


	}

 if(enemy.x5>=4605)
enemy.direction2=0;

if(enemy.x5<4395)
enemy.direction2=1;




// 0 ysar 1 ymin


if(d<-250)
{
enemy.attacking=1;
}

if(enemy.attacking==1)
enemy.posattack.x+=13;







printf("d=%d         \n",d);
printf("enemy.x5=%d \n",enemy.x5);
printf("enemy.image=%d \n",enemy.numeroimage);




return enemy;

}


void affichageattack(Enemy *enemy,SDL_Surface *screen)
 {
if (enemy->attacking==1)
SDL_BlitSurface(enemy->attack,NULL,screen,&enemy->posattack);
}













